checker wordpress admin panel

FORMAT URLS

 site.com/wp-login.php#LOGIN@PASSWORD

OR

 site.com/wp-login.php;LOGIN;PASSWORD



1. Check XMLRPC 

2. Check wp-login